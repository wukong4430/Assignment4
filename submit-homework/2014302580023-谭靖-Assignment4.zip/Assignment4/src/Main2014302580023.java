import java.sql.*;
import java.util.Vector;
public class Main2014302580023 {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	  try{
		  dbconnection db = new dbconnection();
		  Connection con1=db.getConnection();
		  querytable query=new querytable();
		  Vector<E> v1=query.getsearch(con1);
		  System.out.println();
		  for(int i=0;i<(v1.size());i++){
			  System.out.println((search1)v1.get(i));
		  }
	  }	catch(Exception e){e.printStackTrace();
	}

}
class dbconnection{
	private Connection con;
	public Connection getConnection(){
		String url1="";
		String username="";
		String password="";
		try{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			con=DriverMannager.getConnection(url1,username,password);
		}catch(SQLException e){e.printStackTrace();
	}
}