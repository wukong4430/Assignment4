import javax.swing.*;
import java.awt.*;
public class Swingtext {
	static final int WIDTH=600;
	static final int HEIGHT=400;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
     JFrame jf=new JFrame();
     jf.setSize(WIDTH,HEIGHT);
     jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     jf.setTitle("����");
     Toolkit kit=Toolkit.getDefaultToolkit();
     Dimension screenSize=kit.getScreenSize();
     int width=screenSize.width;
     int height=screenSize.height;
     int x=(width-WIDTH)/2;
     int y=(height-HEIGHT)/2;
     jf.setLocation(x, y);
     JTextField jt=new JTextField(10);
     Panel p=new Panel();
     p.add(jt);
     jf.show();
	}

}
