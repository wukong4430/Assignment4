/**
 * �����Ǽ�¼ ���ڵ���Ϣ
 * @author Anjail
 *
 */


public class ProfessorInfo {

	String name;
	String educationBackground;
	String researchInterests;
	String phone;
	String email;
	
	public ProfessorInfo(String name, String educationBackground, String researchInterests, String phone, String email){ 
		this.name = name;
		this.educationBackground = educationBackground;
		this.researchInterests = researchInterests;
		this.phone = phone;
		this.email = email;
	}
	
	public String getName()
	{
		return name;
	}

	public String getEducationBackground() {
		return educationBackground;
	}

	public String getResearchInterests() {
		return researchInterests;
	}

	public String getPhone() {
		return phone;
	}

	public String getEmail() {
		return email;
	}

}
