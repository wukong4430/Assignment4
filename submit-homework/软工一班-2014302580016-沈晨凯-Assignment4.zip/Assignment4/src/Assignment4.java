import java.awt.EventQueue;
import java.awt.TextArea;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import java.awt.BorderLayout;

import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;

import javax.swing.JTextArea;
import javax.swing.JScrollBar;
import javax.swing.JLabel;


public class Assignment4 {

	private JFrame frame;
	private JTextField textField;
	private KeyWordsMatcher kwm;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Assignment4 window = new Assignment4();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Assignment4() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		frame = new JFrame("����һ��");
		frame.setBounds(100, 100, 715, 435);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel = new JPanel();
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(47, 56, 303, 21);
		panel.add(textField);
		textField.setColumns(10);
		
		JTextArea textArea = new JTextArea();
		panel.add(textArea);
		textArea.setBounds(20, 99, 478, 178);
		
		JScrollPane scrollPane = new JScrollPane(textArea);
		scrollPane.setBounds(47, 154, 480, 180);
		panel.add(scrollPane);
		
				scrollPane.setVerticalScrollBarPolicy( 
						JScrollPane.VERTICAL_SCROLLBAR_ALWAYS); 
		
		JButton btnNewButton = new JButton("Search");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				kwm = new KeyWordsMatcher();
				
				//�������Ĺؼ�����������Ϣ�����û���������ؼ���
				if(textField.getText().equals("") || textField.getText().equals("the") || textField.getText().equals("of") || textField.getText().equals("a")
						|| textField.getText().equals("an") || textField.getText().equals(".")) 
					textArea.setText("��������ȷ�Ĺؼ���");
				//����������
				else{
				String input = textField.getText().trim();						//��ȡ�û�������
				kwm.fetchKey(input);											//��ȡ�ؼ��֣��Եõ���ȫ����ʦ��Ϣ������ѡ
				kwm.calc(input);													//����
				kwm.sort();															//����
				
				for(int i=0; i<kwm.resultList.size(); i++)
				{
					
						String name=kwm.resultList.get(i).getPi().getName();
						String educationBackground=kwm.resultList.get(i).getPi().getEducationBackground();
						String researchInterests=kwm.resultList.get(i).getPi().getResearchInterests();
						String email=kwm.resultList.get(i).getPi().getEmail();
						String phone=kwm.resultList.get(i).getPi().getPhone();
						
						String info="Name:"+name+"\n"+"EducationBackground:"+educationBackground+"\n"+"ResearchInterests"+researchInterests+"\n"
								+"email:"+email+"\n"+"phone:"+phone+"\n-----------------------------------------------------------------------------------------\n";
						
						textArea.append(info);
						
					}
				}
			}
		});
		btnNewButton.setBounds(421, 55, 104, 23);
		panel.add(btnNewButton);
		
		JLabel label = new JLabel("������ؼ��֣�ע������ĸ��д��");
		label.setBounds(47, 28, 311, 15);
		panel.add(label);
		
		JLabel label_1 = new JLabel("����������");
		label_1.setBounds(57, 126, 101, 15);
		panel.add(label_1);
		
		
	    /**
		 * ��ɰ�ť���¼���Ӧ ����  �����textArea �С�
		 */
	}
}
